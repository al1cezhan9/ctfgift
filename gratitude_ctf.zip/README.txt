Tammy! John! Welcome!

This is a small puzzle created as a token of our gratitude for your incredible mentorship.

▸ Step 1: Examine the image file closely.
   💡 Hint: Check the metadata for extraction parameters!
▸ Step 2: Open the HTML file in your browser and 👀 INSPECT 👀 it.
▸ Step 3: Try unlocking the ZIP with a title we think you both deserve 🤓!

Yours truly,
— CEET REU