Tammy! John! Welcome to your personalized CTF!

This is a small puzzle created as a token of our gratitude for your incredible mentorship.

▸ Step 1: Examine the image file closely.
   💡 Hint: Check the image metadata for extraction parameters!
▸ Step 2: Open the HTML file in your browser and inspect its source or console.
▸ Step 3: Try unlocking the ZIP with a title you both deserve 🤓

Each step reveals a message from us to you.

Yours truly,
— CEET REU