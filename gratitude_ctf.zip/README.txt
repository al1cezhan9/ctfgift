Welcome to your personalized CTF gift!

This is a small puzzle created as a token of our gratitude for your incredible mentorship.

▸ Step 1: Examine the image file closely.
▸ Step 2: Open the HTML file in your browser and inspect its source or console.
▸ Step 3: Try unlocking the ZIP with a title you both deserve 💛

Each step reveals a message from us to you.

With heartfelt thanks,  
— Your Summer Students